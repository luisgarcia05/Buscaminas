/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aprueba1;

/**
 *
 * @author Windows 10
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Clase principal que muestra el menú inicial del Buscaminas.
 */
public class Aprueba1 {
    private static int filas = 3;
    private static int columnas = 3;
    private static int bombas = 1;

    public static void main(String[] args) {
        mostrarMenuInicial();
    }

    /**
     * Muestra el menú inicial para seleccionar las configuraciones del juego.
     */
    private static void mostrarMenuInicial() {
        JFrame frame = new JFrame("Buscaminas - Menú Inicial");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridLayout(4, 2));

        JLabel labelFilas = new JLabel("Filas:");
        JLabel labelColumnas = new JLabel("Columnas:");
        JLabel labelBombas = new JLabel("Bombas:");
        
        JSlider sliderFilas = new JSlider(3, 10, filas);
        JSlider sliderColumnas = new JSlider(3, 10, columnas);
        JSlider sliderBombas = new JSlider(0, filas * columnas, bombas);
        
        sliderFilas.addChangeListener(e -> {
            filas = sliderFilas.getValue();
            sliderBombas.setMaximum(filas * columnas);
        });
        
        sliderColumnas.addChangeListener(e -> {
            columnas = sliderColumnas.getValue();
            sliderBombas.setMaximum(filas * columnas);
        });
        
        sliderBombas.addChangeListener(e -> bombas = sliderBombas.getValue());

        JButton jugarButton = new JButton("Jugar");
        jugarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Juego iniciado con " + filas + " filas, " + columnas + " columnas y " + bombas + " bombas.");
                frame.dispose();
            }
        });

        frame.add(labelFilas);
        frame.add(sliderFilas);
        frame.add(labelColumnas);
        frame.add(sliderColumnas);
        frame.add(labelBombas);
        frame.add(sliderBombas);
        frame.add(jugarButton);

        frame.setVisible(true);
    }
}
