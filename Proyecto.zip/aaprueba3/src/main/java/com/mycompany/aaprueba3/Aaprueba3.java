/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aaprueba3;

/**
 *
 * @author Windows 10
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Random;


public class Aaprueba3 {
    private static int[][] tablero;
    private static JButton[] botones;
    private static boolean[] bombasColocadas;
    private static boolean[] celdasReveladas;
    private static boolean[] banderasColocadas;
    private static int filas, columnas, totalCeldas, totalBombas, 
            banderasColocadasCount;
    private static JLabel indicadorBanderas;  /* Indicador de banderas 
restantes*/

    public static void main(String[] args) {
        
        /* Ventana principal */
        
        JFrame frame = new JFrame("Buscaminas");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        /* Crear la barra de menú */
        JMenuBar menuBar = new JMenuBar();

        /* Crear el menú "Jugar"*/
        JMenu menu = new JMenu("Jugar");

        /* Se crean las opciónes del menu "Jugar" */
        JMenuItem jugarItem = new JMenuItem("Partida Personalizada");
  
        JMenuItem guardarItem = new JMenuItem("Guardar partida");
        
        JMenuItem generarAleatorioItem = new JMenuItem("Partida Aleatoria");

        /* Se le agrega interaccion a "Jugar"*/
        jugarItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                /* Creacion del panel para selección de filas, 
columnas y bombas*/
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(4, 2));

                /* Creacion del Jspinner para seleccionar las filas, columnas
                y bombas*/
                JSpinner spinnerFilas = 
                        new JSpinner(new SpinnerNumberModel(3, 3, 10, 1)); 
/* Min: 3, Max: 10*/
                JSpinner spinnerColumnas = 
                        new JSpinner(new SpinnerNumberModel(3, 3, 10, 1)); 
/* Min: 3, Max: 10*/
                JSpinner spinnerBombas = 
                        new JSpinner(new SpinnerNumberModel(0, 0, 100, 1)); 
/* Min: 0, Max: 100*/

                /* Ajuste del máximo de bombas basado en las filas y columnas
en el panel*/
                spinnerColumnas.addChangeListener(e2 -> {
                    int maxBombas = (Integer) spinnerFilas.getValue() * 
                            (Integer) spinnerColumnas.getValue();
                    spinnerBombas.setModel(new SpinnerNumberModel(0, 0, 
                            maxBombas, 1));
                });
                spinnerFilas.addChangeListener(e2 -> {
                    int maxBombas = (Integer) spinnerFilas.getValue() * 
                            (Integer) spinnerColumnas.getValue();
                    spinnerBombas.setModel(new SpinnerNumberModel(0, 0, 
                            maxBombas, 1));
                });

                /* Agregar los elementos al panel*/
                panel.add(new JLabel("Filas:"));
                panel.add(spinnerFilas);
                panel.add(new JLabel("Columnas:"));
                panel.add(spinnerColumnas);
                panel.add(new JLabel("Bombas:"));
                panel.add(spinnerBombas);

                /* Mostrar el panel y esperar la respuesta del jugador*/
                int opcion = JOptionPane.showConfirmDialog(frame, panel, 
                        "Selecciona las opciones del juego", 
                        JOptionPane.OK_CANCEL_OPTION);
                
                if (opcion == JOptionPane.OK_OPTION) {
                    int filasInput = (Integer) spinnerFilas.getValue();
                    int columnasInput = (Integer) spinnerColumnas.getValue();
                    int bombasInput = (Integer) spinnerBombas.getValue();

                    int maxBombas = filasInput * columnasInput;  

/* La cantidad máxima de bombas es el total de celdas¨*/

                    if (filasInput >= 3 && filasInput <= 10 && columnasInput >= 
                            3 && columnasInput <= 10) {
                        if (bombasInput <= maxBombas) {
                            filas = filasInput;
                            columnas = columnasInput;

                            /* Se crea el tablero el tablero */
                            crearTablero(filas, columnas, bombasInput);

                            /* Se muestra el tablero en la interfaz 
gráfica*/
                            mostrarTablero(frame);
                        } else {
                            JOptionPane.showMessageDialog(frame, "El número de "
                                    + "bombas no puede ser mayor que " 
                                    + maxBombas + ".");
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "El número de "
                                + "filas y columnas debe estar entre 3 y 10.");
                    }
                }
            }
        });

        /* Se añade un ActionListener a la opción "Guardar partida"*/
        guardarItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guardarPartida(frame);
            }
        });
        
           /* Se añade un ActionListener al ítem "Generar aleatoriamente"*/
        generarAleatorioItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                /* Generación de números aleatorios para filas, columnas y 
                bombas*/
                Random rand = new Random();
                int filasAleatorias = rand.nextInt(8) + 3;  

/* Aleatorio entre 3 y 10*/

                int columnasAleatorias = rand.nextInt(8) + 3; 
                
/* Aleatorio entre 3 y 10*/

                int maxBombas = filasAleatorias * columnasAleatorias;
                int bombasAleatorias = rand.nextInt(maxBombas);  
/* Aleatorio entre 0 y maxBombas*/

                /* Mostrar al jugador las opciones generadas aleatoriamente*/
                JOptionPane.showMessageDialog(frame, "Filas: " 
                        + filasAleatorias + "\nColumnas: " 
                        + columnasAleatorias + "\nBombas: " + bombasAleatorias);

                /* Crear el tablero con los valores aleatorios*/
                filas = filasAleatorias;
                columnas = columnasAleatorias;
                crearTablero(filas, columnas, bombasAleatorias);

                /* Mostrar el tablero en la interfaz */
                mostrarTablero(frame);
            }
        });

        /* Se añaden las opciones al menú*/
        menu.add(jugarItem);
        menu.add(guardarItem);
        menu.add(generarAleatorioItem);

        /* Agregar el menú a la barra*/
        menuBar.add(menu);

        /* Establecer la barra del menú en el marco*/
        frame.setJMenuBar(menuBar);

        /* Mostrar la ventana*/
        frame.setVisible(true);
    }

    /* Creación del tablero*/
    private static void crearTablero(int filas, int columnas, int bombas) {
        totalCeldas = filas * columnas;
        totalBombas = bombas;
        banderasColocadasCount = 0;

        /* Ejecutar el tablero*/
        tablero = new int[totalCeldas][totalCeldas];

        /* Ejecución de los botones, bombas y celdas reveladas*/
        botones = new JButton[totalCeldas];
        bombasColocadas = new boolean[totalCeldas];
        celdasReveladas = new boolean[totalCeldas];
        banderasColocadas = new boolean[totalCeldas];

        /* Conectar las celdas adyacentes (de izquierda a derecha, 
de arriba a abajo)*/
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                int celda = i * columnas + j;
                /* Conectar celdas adyacentes (arriba, abajo, 
                izquierda, derecha)*/
                if (i > 0) tablero[celda][(i - 1) * columnas + j] = 1;
                /* Arriba*/

                if (i < filas - 1) tablero[celda][(i + 1) * columnas + j] = 1;
                /* Abajo*/

                if (j > 0) tablero[celda][i * columnas + (j - 1)] = 1; 
                /* Izquierda*/

                if (j < columnas - 1) tablero[celda][i * columnas + 
                        (j + 1)] = 1; 
                /* Derecha*/

            }
        }

        /* Colocar las bombas de manera aleatoria*/
        Random rand = new Random();
        int bombasColocadasCount = 0;
        while (bombasColocadasCount < bombas) {
            int bomba = rand.nextInt(totalCeldas);
            if (!bombasColocadas[bomba]) {
                bombasColocadas[bomba] = true;
                bombasColocadasCount++;
            }
        }
    }

    /*Mostrar el tablero en la interfaz */
    private static void mostrarTablero(JFrame frame) {
        JPanel panelTablero = new JPanel();
        panelTablero.setLayout(new GridLayout(filas + 1, columnas + 1));  
/* Se añade un +1 para las letras de las columnas y los números de las filas*/

        /* Se crean los encabezados de las columnas (letras A, B, C, ...)*/
        panelTablero.add(new JLabel("")); /* Esquina superior izquierda vacía*/
        for (int i = 0; i < columnas; i++) {
            panelTablero.add(new JLabel(String.valueOf((char) ('A' + i)), 
                    SwingConstants.CENTER));
        }

        /* Indicador de banderas restantes*/
        indicadorBanderas = new JLabel("Banderas restantes: " + 
                (totalBombas - banderasColocadasCount));
        indicadorBanderas.setFont(new Font("Arial", Font.BOLD, 14));
        indicadorBanderas.setForeground(Color.RED);
        frame.getContentPane().add(indicadorBanderas, BorderLayout.NORTH);

        /* Crear las filas del tablero con números y botones*/
        for (int i = 0; i < filas; i++) {
            panelTablero.add(new JLabel(String.valueOf(i + 1), 
                    SwingConstants.CENTER)); /* Agregar el número de fila*/

            for (int j = 0; j < columnas; j++) {
                int celda = i * columnas + j;
                botones[celda] = new JButton("");  /*Preparar los botones */
                botones[celda].setPreferredSize(new Dimension(50, 50));

                /* Accion del click izquierdo*/
                final int index = celda;
                botones[celda].addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        if (bombasColocadas[index]) {
                            botones[index].setText("Bomba");
                            botones[index].setBackground(Color.RED);
                            JOptionPane.showMessageDialog(frame, "¡Perdiste!");
                            reiniciarJuego(frame);  /* Volver al menú */
                        } else {
                            revelarCelda(index, frame);
                            verificarVictoria(frame);  
                            /* Verificar si el jugador ganó*/
                        }
                    }
                });

                /* Colocar y quitar bandera*/
                botones[celda].addMouseListener(new MouseAdapter() {
                    public void mousePressed(MouseEvent e) {
                        if (e.getButton() == MouseEvent.BUTTON3) {
                            if (!celdasReveladas[index]) {
                                if (banderasColocadas[index]) {
                                    banderasColocadas[index] = false;
                                    banderasColocadasCount--;
                                    botones[index].setText("");
                                } else if (banderasColocadasCount < totalBombas) 
                                {
                                    banderasColocadas[index] = true;
                                    banderasColocadasCount++;
                                    botones[index].setText("🚩");
                                }
                                indicadorBanderas.setText("Banderas restantes: " 
                                        + (totalBombas - 
                                                banderasColocadasCount));
                                verificarVictoria(frame);/* Verificar 
                                si el jugador ganó*/
                            }
                        }
                    }
                });

                panelTablero.add(botones[celda]);
            }
        }

        frame.getContentPane().add(panelTablero, BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();
    }

    /* Revelar una casilla / celda*/
    private static void revelarCelda(int index, JFrame frame) {
        celdasReveladas[index] = true;
        botones[index].setEnabled(false);

        /* Mostrar el número de bombas adyacentes*/
        int bombasAdyacentes = contarBombasAdyacentes(index);
        if (bombasAdyacentes > 0) {
            botones[index].setText(String.valueOf(bombasAdyacentes));
        } else {
            botones[index].setText("");
        }

        /* Si no hay bombas adyacentes, revelar las celdas adyacentes*/
        for (int i = 0; i < totalCeldas; i++) {
            if (tablero[index][i] == 1 && !celdasReveladas[i] && 
                    !bombasColocadas[i]) {
                revelarCelda(i, frame);
            }
        }
    }

    /* Función para contar las bombas adyacentes a una casilla o celda*/
    private static int contarBombasAdyacentes(int index) {
        int fila = index / columnas;
        int columna = index % columnas;
        int contador = 0;

        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int nuevaFila = fila + i;
                int nuevaColumna = columna + j;
                if (nuevaFila >= 0 && nuevaFila < filas && nuevaColumna >= 0 
                        && nuevaColumna < columnas) {
                    int nuevaPosicion = nuevaFila * columnas + nuevaColumna;
                    if (bombasColocadas[nuevaPosicion]) {
                        contador++;
                    }
                }
            }
        }
        return contador;
    }

    /*Verificar si el jugador ha ganado*/
    private static void verificarVictoria(JFrame frame) {
        boolean victoria = true;
        for (int i = 0; i < totalCeldas; i++) {
            if (bombasColocadas[i] && !banderasColocadas[i]) {
                victoria = false; /* Si falta una bandera*/
                break;
            }
            if (!bombasColocadas[i] && !celdasReveladas[i]) {
                victoria = false; /* Si hay una celda no 
                revelada que no es bomba*/
                break;
            }
        }

        if (victoria) {
            JOptionPane.showMessageDialog(frame, "¡Felicidades, has ganado!");
            reiniciarJuego(frame); /* Volver al menú */
        }
    }

    /* Reiniciar el juego y volver al menú*/
    private static void reiniciarJuego(JFrame frame) {
        frame.getContentPane().removeAll();
        frame.revalidate();
        frame.repaint();
        frame.setJMenuBar(frame.getJMenuBar());
    }

    /* Guardar la partida en un archivo .txt*/
    private static void guardarPartida(JFrame frame) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar partida");

        /* Abrir el cuadro de guardar archivo*/
        int result = fileChooser.showSaveDialog(frame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                /* Escribir los valores  del tablero*/
                writer.write(filas + " " + columnas + " " + totalBombas + "\n");

                for (int i = 0; i < totalCeldas; i++) {
                    if (bombasColocadas[i]) {
                        writer.write(i + " ");  
                    }
                }
                writer.write("\n");

                for (int i = 0; i < totalCeldas; i++) {
                    if (banderasColocadas[i]) {
                        writer.write(i + " ");  
                    }
                }
                writer.write("\n");

                for (int i = 0; i < totalCeldas; i++) {
                    if (celdasReveladas[i]) {
                        writer.write(i + " ");
                    }
                }

                JOptionPane.showMessageDialog(frame, "La partida "
                        + "fue guardada.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(frame, "Error al "
                        + "guardar la partida.");
            }
        }
    }
}
